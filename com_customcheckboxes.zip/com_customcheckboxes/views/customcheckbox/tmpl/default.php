<?php
defined('_JEXEC') or die;
?>
<form action="index.php?option=com_customcheckboxes&task=customcheckbox.save" method="post">
    <?php foreach ($this->items as $item): ?>
        <input type="checkbox" name="statusCheckbox[]" value="<?php echo $item->Comp_Name; ?>" <?php echo $item->status ? 'checked' : ''; ?>> 
        <?php echo $item->Comp_Name; ?><br>
    <?php endforeach; ?>
    <input type="submit" value="Speichern">
</form>
