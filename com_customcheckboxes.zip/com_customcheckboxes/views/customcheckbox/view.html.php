<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView;

class CustomcheckboxesViewCustomcheckbox extends HtmlView
{
    protected $items;

    public function display($tpl = null)
    {
        $this->items = $this->get('Checkboxes');
        parent::display($tpl);
    }
}
