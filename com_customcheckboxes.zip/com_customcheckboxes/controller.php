<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class CustomcheckboxesController extends BaseController
{
    public function display($cachable = false, $urlparams = [])
    {
        JFactory::getApplication()->input->set('view', JFactory::getApplication()->input->getCmd('view', 'customcheckbox'));
        parent::display($cachable, $urlparams);
    }
}
