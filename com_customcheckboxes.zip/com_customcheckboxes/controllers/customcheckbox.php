<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

class CustomCheckboxesControllerCustomcheckbox extends FormController
{
    public function save($key = NULL, $urlVar = NULL)
    {
        $input = JFactory::getApplication()->input;
        $selectedCheckboxes = $input->post->get('statusCheckbox', [], 'array');
        $db = JFactory::getDbo();

        // Zuerst setzen wir den Status für alle Einträge des aktuellen Benutzers auf 0 (nicht ausgewählt)
        $query = $db->getQuery(true)
            ->update($db->quoteName('spfh_comp_status'))
            ->set($db->quoteName('Status') . ' = 0')
            ->where($db->quoteName('UID_ID') . ' = ' . JFactory::getUser()->id);
        $db->setQuery($query);
        $db->execute();

        // Dann setzen wir den Status für die ausgewählten Checkboxen auf 1
        foreach ($selectedCheckboxes as $compName) {
            $query = $db->getQuery(true)
                ->update($db->quoteName('spfh_comp_status'))
                ->set($db->quoteName('Status') . ' = 1')
                ->where($db->quoteName('Comp_Name') . ' = ' . $db->quote($compName))
                ->where($db->quoteName('UID_ID') . ' = ' . JFactory::getUser()->id);
            $db->setQuery($query);
            $db->execute();
        }

        JFactory::getApplication()->enqueueMessage('Daten erfolgreich gespeichert!', 'message');
        $this->setRedirect(JRoute::_('index.php?option=com_customcheckboxes', false));
    }
}
