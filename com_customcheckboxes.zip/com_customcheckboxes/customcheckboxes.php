<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;

$controller = BaseController::getInstance('Customcheckboxes');
$controller->execute(Factory::getApplication()->input->getCmd('task', 'display'));
$controller->redirect();
