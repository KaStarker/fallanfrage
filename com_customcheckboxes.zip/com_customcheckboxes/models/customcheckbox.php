<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\ListModel;

class CustomcheckboxesModelCustomcheckbox extends ListModel
{
    public function getCheckboxes()
    {


        // Holen Sie die User-ID
        $user = JFactory::getUser();
        $userId = $user->id;

        // Holen Sie den Wert von ufield933
        $db = $this->getDbo();
        $query = $db->getQuery(true)
            ->select($db->quoteName('params'))
            ->from($db->quoteName('spfh_js_job_companies'))
            ->where($db->quoteName('uid') . ' = ' . $db->quote($userId));
        $db->setQuery($query);
        $params = $db->loadResult();
        $paramsArray = json_decode($params, true);
        $ufield933Value = $paramsArray['ufield933'] ?? null;

        // Holen Sie die Stadt-ID basierend auf dem Stadtnamen
        $query = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('spfh_js_job_cities'))
            ->where($db->quoteName('CityName') . ' = ' . $db->quote($ufield933Value));
        $db->setQuery($query);
        $cityId = $db->loadResult();

        // Suche in der Tabelle spfh_comp_status_basis
        $query = $db->getQuery(true)
            ->select([$db->quoteName('UID_ID'), $db->quoteName('Comp_Name')])
            ->from($db->quoteName('spfh_comp_status_basis'))
            ->where($db->quoteName('CityId') . ' = ' . $db->quote($cityId));
        $db->setQuery($query);
        $basisResults = $db->loadObjectList();

        // Überprüfe, ob die Einträge in spfh_comp_status vorhanden sind
        foreach ($basisResults as $result) {
            $query = $db->getQuery(true)
                ->select('COUNT(*)')
                ->from($db->quoteName('spfh_comp_status'))
                ->where($db->quoteName('Comp_Name') . ' = ' . $db->quote($result->Comp_Name))
                ->where($db->quoteName('CityID') . ' = ' . $db->quote($cityId));
            $db->setQuery($query);
            $count = $db->loadResult();

            // Wenn der Eintrag nicht vorhanden ist, füge ihn in spfh_comp_status ein
            if (!$count) {
                $columns = array('UID_ID', 'Comp_Name', 'Status', 'CityId');
                $values = array($db->quote($userId), $db->quote($result->Comp_Name), $db->quote(1), $db->quote($cityId));
                $query = $db->getQuery(true)
                    ->insert($db->quoteName('spfh_comp_status'))
                    ->columns($db->quoteName($columns))
                    ->values(implode(',', $values));
                $db->setQuery($query);
                $db->execute();
            }
        }

        // ...

// Liste alle Einträge der spfh_comp_status auf, die der cityId entsprechen
$query = $db->getQuery(true)
    ->select([$db->quoteName('status'), $db->quoteName('Comp_Name')])
    ->from($db->quoteName('spfh_comp_status'))
    ->where($db->quoteName('UID_ID') . ' = ' . $db->quote($userId))
    ->where($db->quoteName('CityID') . ' = ' . $db->quote($cityId));
$db->setQuery($query);
$finalResults = $db->loadObjectList();

// Anzeige der Firmennamen
foreach ($finalResults as $result) {
    $checked = ($result->status == 1) ? 'checked' : ''; // Setzt 'checked', wenn der Status 1 ist, sonst leer
    echo '<input type="checkbox" name="statusCheckbox[]" value="' . $result->Comp_Name . '" ' . $checked . '> ' . $result->Comp_Name . "<br>";
}


// return $finalResults;

    }
}
